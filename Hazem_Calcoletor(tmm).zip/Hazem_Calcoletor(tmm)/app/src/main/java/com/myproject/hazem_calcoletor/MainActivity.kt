package com.myproject.hazem_calcoletor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception

class MainActivity : AppCompatActivity() {

    var n1 : Double?=null
    var n2 : Double?=null
    var result : Double?=null
    var Process : String?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

     // لل buttons
    fun btn_click(view:View){
    // حتى نستطيع اقتناص الحدث الي من المسنخدم
         try {
             var btn =view as Button
             txtSolution.text= txtSolution.text.toString()+btn.text.toString()
             txtInput.text= txtInput.text.toString()+btn.text.toString()

         }catch (s:Exception){
             Toast.makeText(this,"$s",Toast.LENGTH_LONG).show()
         }

    }

    //استناد قيم للمتغيرات

    fun btn_pross(view: View){

        try {

            var btn = view as Button
            Process=btn.text.toString() // تم الاضافة للمتغير
            n1 = txtSolution.text.toString().toDouble()
            //لمن يضغط على العملية
            txtInput.text=txtInput.text.toString()+btn.text.toString()
            //تم هنا التنظف
            txtSolution.text=""

        }catch (s:Exception){
            Toast.makeText(this,"$s",Toast.LENGTH_LONG).show()
        }


    }

//    txtSolution.text.toString()
//    txtInput.text.toString()

    fun btn_rs(view: View){

        try {
            n2 = txtSolution.text.toString().toDouble()

            if (Process=="+"){
                result =n1!!+n2!!
            }else if(Process=="-"){
                result =n1!!-n2!!
            }else if(Process=="*"){
                result =n1!!*n2!!
            }else if(Process=="/"){
                result =n1!!/n2!!
            }
            txtSolution.text=result.toString()
            txtInput.text=""
        }
        catch (s:Exception){
            Toast.makeText(this,"$s",Toast.LENGTH_LONG).show()
        }

    }

    fun btn_clear(view: View) = try {
        txtInput.text=""
        txtSolution.text =""
        n2=0.0
        n1=0.0

    }catch (s:Exception){
        Toast.makeText(this,"$s",Toast.LENGTH_LONG).show()
    }

}
